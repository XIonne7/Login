﻿Public Class Form1
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        ' Get the entered username and password
        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text

        ' Check if the username and password are valid (replace with your authentication logic)
        If username = "admin" AndAlso password = "password" Then
            MessageBox.Show("Login successful!")
            Form2.Show()


            ' Here you can navigate to another form or perform other actions upon successful login
        Else
            MessageBox.Show("Invalid username or password. Please try again.")
        End If

        ' Clear the password field for security
        txtPassword.Clear()
    End Sub

End Class
